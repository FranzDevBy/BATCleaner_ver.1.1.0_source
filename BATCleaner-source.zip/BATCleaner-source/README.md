Language: Pascal

IDE: Lazarus
